import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrderRoutingModule } from './order-routing.module';
import { CartComponent } from './cart/cart.component';
import { SharedModuleModule } from 'src/app/shared/shared-module.module';
import { PrimeModule } from 'src/app/shared/primeng-module';
import { HistoryComponent } from './history/history.component';
import { OrderSummaryComponent } from './order-summary/order-summary.component';
import {StepsModule} from 'primeng/steps';

@NgModule({
  declarations: [CartComponent, HistoryComponent, OrderSummaryComponent],
  imports: [
    CommonModule,
    OrderRoutingModule,
    SharedModuleModule,
    PrimeModule,
    StepsModule,
  ]
})
export class OrderModule { }
