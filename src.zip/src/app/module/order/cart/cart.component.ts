import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/service/notification-service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartDetails = JSON.parse(sessionStorage.getItem('cart'));
  spinner = false;
  totalAmount = 0;
  paymentOptionFlag = false;
  paymentType = 'PAYTM';
  cardFlag = false;
  pizzaSize = {
    REGULAR: 1,
    MEDIUM: 1,
    LARGE: 1,
  };
  constructor(
    public api: Service,
    private url: UrlConfig,
    private router: Router,
    private notificationService: NotificationService
  ) { }

  /* Calcualte the total price
  @params items having the quantity & price
  @total = quantity * price
  */
  private calculatePrice(items) {
    items.foodList.forEach(cart => {
      cart.totalPrice = cart.quantity * cart.price;
    });
    this.calculateTotal();
  }
  public addQuantity(item) {
    if (item.quantity > 0) {
      item.totalPrice = item.quantity * item.price;
      this.calculateTotal();
    } else {
      item.quantity = 1;
      this.api.alertConfig = this.api.modalConfig('Error', 'Quantity should be atleast one', true, [{ name: 'Ok' }]);
    }
  }

/* Remove the Quantity
  @params items having the quantity & price
  @total = quantity * price
  @condition is more tham one quantity
 */
  public removeQuantity(item) {
    if (item.quantity > 1) {
      item.quantity -= 1;
      item.totalPrice = item.quantity * item.price;
      this.calculateTotal();
    } else {
      this.api.alertConfig = this.api.modalConfig('Error', 'Quantity should be atleast one', true, [{ name: 'Ok' }]);
    }
  }

  /* Remove the cart
  @item is more tham one quantity
 */
  public removeCart(item) {
    const index = this.cartDetails.foodList.findIndex(card => card.foodId === item.foodId);
    if (index !== -1) {
      this.cartDetails.foodList.splice(index, 1);
    }
    sessionStorage.setItem('cart', JSON.stringify(this.cartDetails));
    // this.notificationService.sendMessage({ cart: this.cartDetails });
    const finalList = JSON.parse(sessionStorage.getItem('cart'));
    const user = this.api.loggedUser();
    user.cart = finalList;
    this.notificationService.sendMessage( user );
    this.calculateTotal();
  }
  /* Modal Action
  @param Ok modal has been closed
 */
  public modalAction(action: string): void {
    if (action === 'Ok') {
      this.spinner = false;
      this.api.alertConfigDefaultValue();
    } else {
      this.spinner = false;
      this.api.alertConfigDefaultValue();
      this.router.navigate(['/order/summary']);

    }
  }

   /*Calculate the total price
   @param total = 0
 */
  private calculateTotal() {
    let total = 0;
    this.cartDetails.foodList.forEach(cart => {
      total += cart.totalPrice;
    });
    this.totalAmount = total;
  }


  ngOnInit() {
    if (this.cartDetails && this.cartDetails.foodList) {
      this.calculatePrice(this.cartDetails);
      this.cardFlag = true;
    } else {
      this.cardFlag = false;
    }
    const finalList = JSON.parse(sessionStorage.getItem('cart'));
    const user = this.api.loggedUser();
    user.cart = finalList;
    this.notificationService.sendMessage( user );
  }

  placeOrder = () => {
    const user = this.api.loggedUser();
    this.cartDetails.paymentType = this.paymentType;
    this.cartDetails.totalAmount = this.totalAmount;
    const params = `/${user.userId}/orders`;
    this.api.postCall(this.url.urlConfig().placeOrder.concat(params), this.cartDetails, 'post').subscribe(order => {
      if (order.statusCode === 200) {
        this.spinner = false;
        this.cartDetails = [];
        sessionStorage.setItem('cart', JSON.stringify(this.cartDetails));
        this.notificationService.sendMessage({ cart: this.cartDetails });
        this.api.alertConfig = this.api.modalConfig('', order.message, true, [{ name: 'Close' }]);
        setTimeout(() => {
        }, 3000);
        this.router.navigate(['/order/summary']);
      } else {
        this.api.alertConfig = this.api.modalConfig('', order.message, true, [{ name: 'Ok' }]);
      }
    });
  }

}
