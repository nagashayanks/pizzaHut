import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { HistoryComponent } from './history/history.component';
import { OrderSummaryComponent } from './order-summary/order-summary.component';


const routes: Routes = [
  {
    path: '',
    component: CartComponent
  },
  {
    path: 'cart',
    component: CartComponent
  },
  {
    path: 'history',
    component: HistoryComponent
  },
  {
    path: 'summary',
    component: OrderSummaryComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrderRoutingModule { }
