import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';
import { OrderHistory } from 'src/app/model/model';
import { NotificationService } from 'src/app/service/notification-service';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {
  spinner = false;
  orderSummary: OrderHistory[];
  constructor(
    public api: Service,
    private url: UrlConfig,
    private notificationService: NotificationService
  ) { }

    /* get Order list */
  private geOrderSummary(): void {
    this.spinner = true;
    const user = this.api.loggedUser();
    const params = `/${user.userId}/orders`;
    this.api.getList(this.url.urlConfig().orderSummary.concat(params)).subscribe(order => {
        this.spinner = false;
        this.orderSummary = order.orderSummarys;
    }, error => {
      this.spinner = false;
    });
  }
  ngOnInit() {
    this.geOrderSummary();
    const finalList = JSON.parse(sessionStorage.getItem('cart'));
    const user = this.api.loggedUser();
    user.cart = finalList;
    this.notificationService.sendMessage( user );
  }
}
