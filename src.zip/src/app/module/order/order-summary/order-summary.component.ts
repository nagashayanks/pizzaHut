import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';
import { NotificationService } from 'src/app/service/notification-service';

@Component({
  selector: 'app-order-summary',
  templateUrl: './order-summary.component.html',
  styleUrls: ['./order-summary.component.css']
})
export class OrderSummaryComponent implements OnInit {
items;
activeIndex: number;
  constructor(
    public api: Service,
    private url: UrlConfig,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {
    const finalList = JSON.parse(sessionStorage.getItem('cart'));
    const user = this.api.loggedUser();
    user.cart = finalList;
    this.notificationService.sendMessage( user );
    this.items = [{
      label: 'Ordered',
      command: (event: any) => {
          this.activeIndex = 0;
      }
  },
  {
      label: 'Confirmed',
      command: (event: any) => {
          this.activeIndex = 1;
      }
  },
  {
    label: 'Preparing',
    command: (event: any) => {
        this.activeIndex = 2;
    }
},
 {
      label: 'Shipped',
      command: (event: any) => {
          this.activeIndex = 3;
      }
  },
  {
      label: 'Delevered',
      command: (event: any) => {
          this.activeIndex = 4;
      }
  }
];
}
}
