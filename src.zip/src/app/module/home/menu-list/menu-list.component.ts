import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/service/notification-service';
@Component({
  selector: 'app-menu-list',
  templateUrl: './menu-list.component.html',
  styleUrls: ['./menu-list.component.css']
})
export class MenuListComponent implements OnInit {
  spinner = false;
  products: any;
  preferences: any;
  foodlist: any;
  size;
  menulistVeg = [];
  foodList = [];
  menulistNonVeg = [];


  constructor(
    public api: Service,
    private url: UrlConfig,
    private router: Router,
    private notification: NotificationService) {
    this.size = [
      { name: 'Regular', value: 'REGULAR' },
      { name: 'Medium', value: 'MEDIUM' },
      { name: 'Large', value: 'LARGE' }
    ];
  }

  private addQuantityFlag(item) {
    item.forEach(element => {
      element.foodList.forEach(food => {
        food.quantity = 0;
        food.pizzaSize = 'REGULAR';
      });
    });
    return item;
  }
  /* get data list */
  private geProductList(): void {
    this.spinner = true;
    const user = this.api.loggedUser();
    const params = `/${user.userId}/foods`;
    this.api.getList(this.url.urlConfig().allMenu.concat(params)).subscribe(data => {
      this.spinner = false;
      const seprateGroup = data.allMenuList.reduce((r, a) => {
        r[a.categoryName] = [...r[a.categoryName] || [], a];
        return r;
      }, {});
      this.menulistVeg = this.addQuantityFlag(seprateGroup.Veg);
      this.menulistNonVeg = this.addQuantityFlag(seprateGroup.NonVeg);
    });
  }
  public addFood(item) {
    item.quantity += 1;
    this.foodList = [];
    const cartList = JSON.parse(sessionStorage.getItem('cart'));
    if (cartList && cartList.foodList && cartList.foodList.length) {
      this.foodList = cartList.foodList;
    }
    if (this.foodList && this.foodList.length) {
      const index = this.foodList.findIndex(card => card.foodId === item.foodId);
      if (index !== -1) {
        this.foodList[index].quantity += 1;
      } else {
        this.foodList.push({
          foodName: item.foodName,
          foodId: item.foodId,
          quantity: item.quantity,
          price: item.price
        });
      }
    } else {
      this.foodList.push({
        foodName: item.foodName,
        foodId: item.foodId,
        quantity: item.quantity,
        price: item.price
      });
    }
    const finalList = {
      paymentType: null,
      foodList: this.foodList
    };
    sessionStorage.setItem('cart', JSON.stringify(finalList));
    const user = this.api.loggedUser();
    user.cart = finalList;
    this.notification.sendMessage( user );
  }
  ngOnInit() {
    this.geProductList();
    const finalList = JSON.parse(sessionStorage.getItem('cart'));
    const user = this.api.loggedUser();
    user.cart = finalList;
    this.notification.sendMessage( user );
  }
}
