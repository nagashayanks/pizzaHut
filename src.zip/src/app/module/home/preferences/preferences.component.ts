import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/service/notification-service';

@Component({
  selector: 'app-preferences',
  templateUrl: './preferences.component.html',
  styleUrls: ['./preferences.component.css']
})
export class PreferencesComponent implements OnInit {
  responsiveOptions;
  spinner = false;
  products: any;
  preferences: any[];
  foodList = [];
  constructor(public api: Service,
    private url: UrlConfig,
    private router: Router,
    private notification: NotificationService) {

    this.responsiveOptions = [
      {
        breakpoint: '1024px',
        numVisible: 2,
        numScroll: 2
      },
      {
        breakpoint: '768px',
        numVisible: 2,
        numScroll: 2
      },
      {
        breakpoint: '560px',
        numVisible: 1,
        numScroll: 1
      }
    ];
  }

  public addFood(item) {
    item.quantity += 1;
    this.foodList = [];
    const cartList = JSON.parse(sessionStorage.getItem('cart'));
    if (cartList && cartList.foodList &&  cartList.foodList.length) {
      this.foodList = cartList.foodList;
    }
    if (this.foodList && this.foodList.length) {
      const index = this.foodList.findIndex(card => card.foodId === item.foodId);
      if (index !== -1) {
        this.foodList[index].quantity += 1;
      } else {
        this.foodList.push({
          foodName: item.foodName,
          foodId: item.foodId,
          quantity: item.quantity,
          price: item.price
        });
      }
    } else {
      this.foodList.push({
        foodName: item.foodName,
        foodId: item.foodId,
        quantity: item.quantity,
        price: item.price
      });
    }
    const finalList = {
      paymentType: null,
      foodList: this.foodList
    };
    sessionStorage.setItem('cart', JSON.stringify(finalList));
    const user = this.api.loggedUser();
    user.cart = finalList;
    this.notification.sendMessage(user);
  }

  ngOnInit() {

    this.getPreferences();
  }
  private getPreferences(): void {
    this.spinner = true;
    const user = this.api.loggedUser();
    const params = `/${user.userId}/foods`;
    this.api.getList(this.url.urlConfig().preferences.concat(params)).subscribe(data => {
      this.spinner = false;
      this.preferences = data.preferenceList;
    });
  }
}
