import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/service/service';
import { Router } from '@angular/router';
import { UrlConfig } from 'src/app/service/url-config';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(public api: Service,
              private url: UrlConfig,
              private router: Router) {

               }

  ngOnInit() {

  }

}
