import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { HomeRoutingModule } from './home-routing.module';
import { MenuListComponent } from './menu-list/menu-list.component';
import { HomeComponent } from './home.component';
import { PreferencesComponent } from './preferences/preferences.component';
import { PrimeModule } from 'src/app/shared/primeng-module';
import { SharedModuleModule } from 'src/app/shared/shared-module.module';


@NgModule({
  declarations: [MenuListComponent, HomeComponent, PreferencesComponent],
  imports: [
    CommonModule,
    NgbModule,
    HomeRoutingModule,
    PrimeModule,
    SharedModuleModule
  ]
})
export class HomeModule { }
