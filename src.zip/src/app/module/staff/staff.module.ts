import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { StaffRoutingModule } from './staff-routing.module';
import { StaffComponent } from './component/staff.component';
import { PrimeModule } from 'src/app/shared/primeng-module';


@NgModule({
  declarations: [StaffComponent],
  imports: [
    CommonModule,
    StaffRoutingModule,
    NgbModule,
    PrimeModule
  ]
})
export class StaffModule { }
