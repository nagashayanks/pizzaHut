import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MemberRoutingModule } from './member-routing.module';
import { LoginComponent } from './login/login.component';
import { SharedModuleModule } from '../../shared/shared-module.module';
import { StaffRegisterComponent } from './staff-register/staff-register.component';


@NgModule({
  declarations: [LoginComponent, StaffRegisterComponent],
  imports: [
    CommonModule,
    MemberRoutingModule,
    SharedModuleModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MemberModule { }
