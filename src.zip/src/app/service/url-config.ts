import { Injectable } from '@angular/core';
@Injectable()
export class UrlConfig {
    serverConfig = true;
    private apiHost = 'http://10.117.189.111:9090/pizzahut/';
    private apiMock = 'http://localhost:3000/';
    url = {};

    /* url config with url Mock list */
    urlMock() {
        return this.url = {
            userLogin: 'http://10.117.189.111:9090/pizzahut/' + 'users',
            userList: this.apiMock + 'users',
            vendorMenu: this.apiMock + 'ItemcategoryList',
            brand: this.apiMock + 'brands',
            vendors: this.apiHost + 'vendors',
            placeOrder: this.apiMock + 'employees',
            orderSummary: this.apiMock + 'employees',
            preferences: this.apiMock + 'preferences',
            allMenu: this.apiMock + 'allMenu'
        };
    }
    /* url config with url Server list */
    urlApi() {
        return this.url = {
            userLogin: this.apiHost + 'users',
            userList: this.apiHost + 'users',
            placeOrder: this.apiHost + 'users',
            orderSummary: this.apiHost + 'users',
            preferences: this.apiHost + 'users',
            allMenu: this.apiHost + 'users'

        };
    }

     /* return url */
    urlConfig() {
        return  this.serverConfig ? this.urlApi() : this.urlMock() ;
    }
}
