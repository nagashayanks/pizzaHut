export interface User {
    firstName: string;
    email: string;
    gender: string;
    username: string;
    password: string;
    acceptTerms: boolean;
    id: number;
}
export interface OrderHistory {
    userOrderId: number;
    orderDate: string;
    orderStatus: string;
    paymentType: string;
    totalAmount: number;
    orderedFood: [
      {
        foodName: string;
        quantity: number;
      }
    ];
}
export interface Account {
    accountNumber: number;
    accountType: string;
    balance: number;
    ifscCode: string;
    userId: number;
}
export interface CurrentUser {
    userId: number;
    userName: string;
    role: string;
    cart: [];
}

export interface TransactionSummary {
    transactionId: number;
    fromAccount: number;
    toAccount: number;
    amount: number;
    status: string;
    transactionDate: string;
    ifscCode: string;
    benefactorName: string;
}
export interface UserGroup {
    userId: number;
    groupName: string;
    groupId: number;
    id: number;
}
export interface UserDetail {
    id: number;
    name: string;
}

export interface UserPreference {
  foodId: number;
  foodName: string;
  price: number;
  rating: number;
}
